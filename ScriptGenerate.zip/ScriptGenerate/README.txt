Import the json file from zeppelin and generate several independent script that can be executed.
Type support: bash, python, pyspark
Working on Scala

##How to Use##
Python PATH_OF_SCRIPT -s PATH_OF_JSON_FILE -o